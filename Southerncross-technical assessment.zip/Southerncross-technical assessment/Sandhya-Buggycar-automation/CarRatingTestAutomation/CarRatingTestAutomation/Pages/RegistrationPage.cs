﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CarRatingTestAutomation.Pages
{
    public class RegistrationPage
    {
        public IWebDriver driver;
        public RegistrationPage(IWebDriver webDriver)
        {
            driver = webDriver;
        }
        //find Id for login field and assign input parameter
        IWebElement txtLogin => driver.FindElement(By.Id("username"));

       // find Id for firstname field and assign input parameter
        IWebElement txtFirstName => driver.FindElement(By.Id("firstName"));

        // find Id for lastName field and assign input parameter
        IWebElement txtLastName => driver.FindElement(By.Id("lastName"));

        //find Id for password field and assign input parameter
        IWebElement txtPassword => driver.FindElement(By.Id("password"));

        // find Id for confirmPassword field and assign input parameter
        IWebElement txtConfirmPassword => driver.FindElement(By.Id("confirmPassword"));

        //find xpath for Register button and assign input parameter
        IWebElement btnRegister => driver.FindElement(By.XPath("//button[text()='Register']"));

        //find xpath for success or failure message
        IWebElement alertMessage => driver.FindElement(By.XPath("//div[contains(@class, 'result alert alert')]"));

        public void Register(string login, string firstname, string lastname, string password, string confirmPassword)
        {
            txtLogin.SendKeys(login);
            txtFirstName.SendKeys(firstname);
            txtLastName.SendKeys(lastname);
            txtPassword.SendKeys(password);
            txtConfirmPassword.SendKeys(confirmPassword);
            btnRegister.Click();
        }

        public void ValidateMessage(string message)
        {
            Thread.Sleep(1000);
            string textMessage = alertMessage.Text;

            //assert expected result = actual result
            Assert.IsTrue(textMessage.Contains(message), "Alert message is incorrect and displayed: " + textMessage);
        }

    }
}
